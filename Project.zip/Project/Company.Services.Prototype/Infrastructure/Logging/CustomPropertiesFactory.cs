﻿using System.Collections.Generic;

namespace Company.Services.Prototype.Infrastructure.Logging
{
    public static class CustomPropertiesFactory
    {
        public static Dictionary<string, object> Create(string message)
        {
            return new Dictionary<string, object> { ["message"] = message };
        }
    }
}
