using Company.Services.Prototype.Infrastructure.Logging;
using Company.Services.Prototype.Services.Interfaces;
using Company.Services.Prototype.Services.Messaging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Company.Services.Prototype.Functions
{
    public class DealFunctions
    {
        private readonly ILogger logger;
        private readonly IDealService dealService;

        public DealFunctions(ILogger<DealFunctions> logger, IDealService dealService)
        {
            this.logger = logger;
            this.dealService = dealService;
        }

        [FunctionName(nameof(GetDealsAsync))]
        public async Task<IActionResult> GetDealsAsync([HttpTrigger(AuthorizationLevel.Function)] GetDealRequest request)
        {
            using (logger.BeginScope(CustomPropertiesFactory.Create(request.PortfolioId)))
            {
                GetDealResponse response = await dealService.GetDealAsync(request);

                if (response.HasError)
                {
                    return new ContentResult
                    {
                        StatusCode = StatusCodes.Status500InternalServerError,
                        Content = response.ErrorMessage
                    };
                }

                return new OkObjectResult(response);
            }
        }

        [FunctionName(nameof(GetDealsAsync))]
        public async Task<IActionResult> CreateDealAsync([HttpTrigger(AuthorizationLevel.Function)] CreateDealRequest request)
        {
            using (logger.BeginScope(CustomPropertiesFactory.Create(request.Name)))
            {
                CreateDealResponse response = await dealService.CreateDealAsync(request);

                if (response.HasError)
                {
                    return new ContentResult
                    {
                        StatusCode = StatusCodes.Status500InternalServerError,
                        Content = response.ErrorMessage
                    };
                }

                return new OkObjectResult(response);
            }
        }
    }
}
