﻿## Layers
* Domain: core (a.k.a. Models)
* Data: repository implementation
* Services: application business logic (a.k.a. Application)
* Presentation: (Azure Functions)
* Infrastructure: cross-cutting concerns

## Patterns

### Request/ Response
* Pass messages from Presentation to Services.
* Response contains error or validation messages as an alternative to throwing exceptions.
* Messages a.k.a. DTOs or Contracts.
* Wrapper on the response. ErrorMessage, HasError, can be extended with IsFound, TotalCount, PageNumber, etc.

### DTOs
* Stands for Data Transformation Objects.
* Views of the model.

### Scoped Logging
* Log custom properties into Application Insight (e.g. Portfolio ID) in order to query logs.

### Mapping with Automapper
* Used in the Services layer to map service DTOs to domain entities and viceversa.

### Open Questions
* Repositories (IAggregateRoot, never IQueryable, IList vs IEnumerable)
* Separate projects for Domain, Services, Data
* Share Domain and Infrastructure vs. share-nothing
* Isolated vs. In-Process function (Dependency Injection)
* Unit test framework (MSTest, NUnit, xUnit)
* One solution for all microservices vs. one solution for each microservice
* Solution / Project naming convention