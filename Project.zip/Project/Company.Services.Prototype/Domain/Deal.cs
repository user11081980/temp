﻿namespace Company.Services.Prototype.Domain
{
    public class Deal
    {
        public string PortfolioId { get; set; }
        public bool IsRated { get; set; }
        public string Name { get; set; }
        public double TotalAuthorizedAmount { get; set; }
        public string RelationshipManagerName { get; set; }
        public string RelationshipManagerEmail { get; set; }
    }
}
