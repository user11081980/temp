﻿using Company.Services.Prototype.Services.Messaging;
using System.Threading.Tasks;

namespace Company.Services.Prototype.Services.Interfaces
{
    public interface IDealService
    {
        Task<GetDealResponse> GetDealAsync(GetDealRequest request);
        Task<CreateDealResponse> CreateDealAsync(CreateDealRequest request);
    }
}
