﻿using AutoMapper;
using Company.Services.Prototype.Data.Repositories.Interfaces;
using Company.Services.Prototype.Domain;
using Company.Services.Prototype.Services.Interfaces;
using Company.Services.Prototype.Services.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Company.Services.Prototype.Services.Implementation
{
    public class DealService : IDealService
    {
        private readonly ILogger logger;
        private readonly IDealRepository dealRepository;
        private readonly IMapper mapper;

        public DealService(ILogger<DealService> logger, IDealRepository dealRepository, IMapper mapper)
        {
            this.logger = logger;
            this.dealRepository = dealRepository;
            this.mapper = mapper;
        }

        public async Task<GetDealResponse> GetDealAsync(GetDealRequest request)
        {
            try
            {
                Deal deal = await dealRepository.GetDealByIdAsync(request.PortfolioId);

                GetDealResponse response = mapper.Map<GetDealResponse>(deal);

                return response;
            }
            catch (Exception ex)
            {
                logger.LogWarning("", ex);
                return new GetDealResponse { ErrorMessage = "" };
            }
        }

        public async Task<CreateDealResponse> CreateDealAsync(CreateDealRequest request)
        {
            try
            {
                Deal deal = mapper.Map<Deal>(request);

                string portfolioId = await dealRepository.CreateDealAsync(deal);

                CreateDealResponse response = new CreateDealResponse { PortfolioId = portfolioId };

                return response;
            }
            catch (Exception ex)
            {
                logger.LogWarning("", ex);
                return new CreateDealResponse { ErrorMessage = "" };
            }
        }
    }
}
