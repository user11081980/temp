﻿namespace Company.Services.Prototype.Services.Dtos
{
    public class DealDto
    {
        public string PortfolioId { get; set; }
        public bool IsRated { get; set; }
        public string Name { get; set; }
        public double TotalAuthorizedAmount { get; set; }
        public string RelationshipManagerName { get; set; }
        public string RelationshipManagerEmail { get; set; }
    }
}
