﻿using Company.Services.Prototype.Infrastructure.Messaging;
using Company.Services.Prototype.Services.Dtos;

namespace Company.Services.Prototype.Services.Messaging
{
    public class GetDealResponse : ResponseBase
    {
        public DealDto Deal { get; set; }
    }
}
