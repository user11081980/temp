﻿namespace Company.Services.Prototype.Services.Messaging
{
    public class GetDealRequest
    {
        public string PortfolioId { get; set; }
    }
}
