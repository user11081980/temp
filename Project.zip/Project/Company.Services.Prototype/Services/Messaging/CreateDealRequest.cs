﻿namespace Company.Services.Prototype.Services.Messaging
{
    public class CreateDealRequest
    {
        public bool IsRated { get; set; }
        public string Name { get; set; }
        public double TotalAuthorizedAmount { get; set; }
        public string RelationshipManagerName { get; set; }
        public string RelationshipManagerEmail { get; set; }
    }
}
