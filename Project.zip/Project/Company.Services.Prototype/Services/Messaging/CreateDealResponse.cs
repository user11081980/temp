﻿using Company.Services.Prototype.Infrastructure.Messaging;

namespace Company.Services.Prototype.Services.Messaging
{
    public class CreateDealResponse : ResponseBase
    {
        public string PortfolioId { get; set; }
    }
}
