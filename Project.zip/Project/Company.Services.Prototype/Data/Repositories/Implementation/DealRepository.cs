﻿namespace Company.Services.Prototype.Data.Repositories.Implementation
{
    public class DealRepository
    {
    }
}
