﻿using Company.Services.Prototype.Domain;
using System.Threading.Tasks;

namespace Company.Services.Prototype.Data.Repositories.Interfaces
{
    public interface IDealRepository
    {
        Task<Deal> GetDealByIdAsync(string id);

        Task<string> CreateDealAsync(Deal deal);
    }
}
